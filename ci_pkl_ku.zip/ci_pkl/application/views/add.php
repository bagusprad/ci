<form method="POST">
	<div class="form-group">
	    <label>Nama Warung</label>
		<input type="text" name="nama_warung" class="form-control" placeholder="Nama Warung">
	</div>
	<div class="form-group">
		<label>Nama Penjual</label>
		<input type="text" name="nama_penjual" class="form-control" placeholder="Nama Penjual">
	</div>
	<button type="submit" class="btn btn-primary" name="submit" value="1!1">Simpan</button>
</form>